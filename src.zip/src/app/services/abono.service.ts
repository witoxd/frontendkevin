import { Injectable } from "@angular/core"
import  { HttpClient, HttpErrorResponse } from "@angular/common/http"
import {  Observable, throwError } from "rxjs"
import { catchError, map } from "rxjs/operators"
import  { Abono, CreateAbonoRequest, UpdateAbonoRequest } from "../models/abono.model"
import  { ApiResponse } from "../models/api-response.model"

@Injectable({
  providedIn: "root",
})
export class AbonoService {
  private readonly apiUrl = "http://localhost:3000/api/abonos"

  constructor(private http: HttpClient) {
    const token = typeof window !== 'undefined' ? localStorage.getItem('token') || '' : ''

  }

  getAbonos(): Observable<Abono[]> {
    return this.http.get<ApiResponse<Abono[]>>(this.apiUrl).pipe(
      map((response) => response.data!),
      catchError(this.handleError),
    )
  }

  getAbonoById(id: number): Observable<Abono> {
    return this.http.get<ApiResponse<Abono>>(`${this.apiUrl}/${id}`).pipe(
      map((response) => response.data!),
      catchError(this.handleError),
    )
  }

  getAbonosByEmpeno(empenoId: number): Observable<Abono[]> {
    return this.http.get<ApiResponse<Abono[]>>(`${this.apiUrl}/empeno/${empenoId}`).pipe(
      map((response) => response.data!),
      catchError(this.handleError),
    )
  }

  createAbono(abonoData: CreateAbonoRequest): Observable<Abono> {
    return this.http.post<ApiResponse<Abono>>(this.apiUrl, abonoData).pipe(
      map((response) => response.data!),
      catchError(this.handleError),
    )
  }

  updateAbono(id: number, abonoData: UpdateAbonoRequest): Observable<Abono> {
    return this.http.put<ApiResponse<Abono>>(`${this.apiUrl}/${id}`, abonoData).pipe(
      map((response) => response.data!),
      catchError(this.handleError),
    )
  }

  deleteAbono(id: number): Observable<any> {
    return this.http.delete<ApiResponse<any>>(`${this.apiUrl}/${id}`).pipe(catchError(this.handleError))
  }

  private handleError(error: HttpErrorResponse): Observable<never> {
    let errorMessage = "Ha ocurrido un error desconocido"

    if (error.error instanceof ErrorEvent) {
      errorMessage = `Error: ${error.error.message}`
    } else {
      errorMessage = error.error?.message || `Error ${error.status}: ${error.statusText}`
    }

    return throwError(() => new Error(errorMessage))
  }
}

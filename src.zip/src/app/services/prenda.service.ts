import { Injectable } from "@angular/core"
import  { HttpClient, HttpErrorResponse } from "@angular/common/http"
import {  Observable, throwError } from "rxjs"
import { catchError, map } from "rxjs/operators"
import  { Prenda, CreatePrendaRequest, UpdatePrendaRequest } from "../models/prenda.model"
import  { ApiResponse } from "../models/api-response.model"
import {   HttpHeaders } from "@angular/common/http"
@Injectable({
  providedIn: "root",
})
export class PrendaService {
  private readonly apiUrl = "http://localhost:3000/api/prendas"

  constructor(private http: HttpClient) {
    const token = typeof window !== 'undefined' ? localStorage.getItem('token') || '' : ''

  }

    private getAuthHeaders(): HttpHeaders {
    const token = localStorage.getItem("authToken")
    return new HttpHeaders({
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
    })
  }

  getPrendas(): Observable<Prenda[]> {
    return this.http.get<ApiResponse<Prenda[]>>(this.apiUrl, { headers: this.getAuthHeaders() }).pipe(
      map((response) => response.data!),
      catchError(this.handleError),
    )
  }

  getPrendaById(id: number): Observable<Prenda> {
    return this.http.get<ApiResponse<Prenda>>(`http://localhost:3000/api/empenos/${id}/prendas`, { headers: this.getAuthHeaders() }).pipe(
      map((response) => response.data!),
      catchError(this.handleError),
    )
  }

  getPrendasByCliente(id: number): Observable<Prenda[]> {
    return this.http.get<ApiResponse<Prenda[]>>(`http://localhost:3000/api/empenos/${id}/prendas`, { headers: this.getAuthHeaders() }).pipe(
      map((response) => response.data!),
      catchError(this.handleError),
    )
  }

  getPrendasByEstado(estado: string): Observable<Prenda[]> {
    return this.http.get<ApiResponse<Prenda[]>>(`${this.apiUrl}/${estado}`, { headers: this.getAuthHeaders() }).pipe(
      map((response) => response.data!),
      catchError(this.handleError),
    )
  }

  createPrenda(prendaData: CreatePrendaRequest): Observable<Prenda> {
    return this.http.post<ApiResponse<Prenda>>(this.apiUrl, prendaData, { headers: this.getAuthHeaders() }).pipe(
      map((response) => response.data!),
      catchError(this.handleError),
    )
  }

  updatePrenda(id: number, prendaData: UpdatePrendaRequest): Observable<Prenda> {
    return this.http.put<ApiResponse<Prenda>>(`${this.apiUrl}/${id}`, prendaData, { headers: this.getAuthHeaders() }).pipe(
      map((response) => response.data!),
      catchError(this.handleError),
    )
  }

  deletePrenda(id: number): Observable<any> {
    return this.http.delete<ApiResponse<any>>(`${this.apiUrl}/${id}`, { headers: this.getAuthHeaders() }).pipe(catchError(this.handleError))
  }

  private handleError(error: HttpErrorResponse): Observable<never> {
    let errorMessage = "Ha ocurrido un error desconocido"

    if (error.error instanceof ErrorEvent) {
      errorMessage = `Error: ${error.error.message}`
    } else {
      errorMessage = error.error?.message || `Error ${error.status}: ${error.statusText}`
    }

    return throwError(() => new Error(errorMessage))
  }
}

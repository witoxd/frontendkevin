export interface Abono {
  id: number
  monto: number
  fecha_abono: Date
  empenoId: number
  userId: number
  createdAt?: Date
  updatedAt?: Date
}

export interface CreateAbonoRequest {
  monto: number
  fecha_abono: Date
  empenoId: number
  userId: number
}

export interface UpdateAbonoRequest {
  monto?: number
  fecha_abono?: Date
  empenoId?: number
  userId?: number
}

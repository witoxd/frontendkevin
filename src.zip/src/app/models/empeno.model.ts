export interface Empeno {
  id: number
  monto_prestado: number
  interes_mensual: number
  fecha_vencimiento: Date
  estado: "activo" | "pagado" | "vencido" | "perdido"
  cliente_id: number
  prenda_id: number
  user_id: number
  createdAt?: Date
  updatedAt?: Date
}

export interface CreateEmpenoRequest {
  monto_prestado: number
  interes_mensual: number
  fecha_vencimiento: Date
  estado: "activo" | "pagado" | "vencido" | "perdido"
  cliente_id: number
  prenda_id: number
  user_id: number
}

export interface UpdateEmpenoRequest {
  monto_prestado?: number
  interes_mensual?: number
  fecha_vencimiento?: Date
  estado: "activo" | "pagado" | "vencido" | "perdido"
  cliente_id?: number
  prenda_id?: number
  user_id?: number
}

export interface Prenda {
  id: number
  descripcion: string
  peso?: number
  kilates?: number
  valor_estimado: number
  estado: "disponible" | "empenada" | "vendida" | "perdida"
  cliente_id: number
  createdAt?: Date
  updatedAt?: Date
}

export interface CreatePrendaRequest {
  descripcion: string
  peso?: number
  kilates?: number
  valor_estimado: number
  estado?: "disponible" | "empenada" | "vendida" | "perdida"
  cliente_id: number
}

export interface UpdatePrendaRequest {
  descripcion?: string
  peso?: number
  kilates?: number
  valor_estimado?: number
  estado?: "disponible" | "empenada" | "vendida" | "perdida"
  cliente_id?: number
}

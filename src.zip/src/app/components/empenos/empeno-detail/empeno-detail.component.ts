import { Component,  OnInit } from "@angular/core"
import { CommonModule } from "@angular/common"
import {  ActivatedRoute,  Router, RouterModule } from "@angular/router"
import  { EmpenoService } from "../../../services/empeno.service"
import  { PrendaService } from "../../../services/prenda.service"
import  { ClienteService } from "../../../services/cliente.service"
import  { Empeno } from "../../../models/empeno.model"
import  { Prenda } from "../../../models/prenda.model"
import  { Cliente } from "../../../models/cliente.model"
import { isPlatformBrowser } from '@angular/common';
import {  Inject, PLATFORM_ID } from '@angular/core';

@Component({
  selector: "app-empeno-detail",
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: "./empeno-detail.component.html",
  styleUrls: ["./empeno-detail.component.css"],
})
export class EmpenoDetailComponent implements OnInit {
  empeno: Empeno | null = null
  prenda: Prenda | null = null
  cliente: Cliente | null = null
  loading = true
  error: string | null = null
  currentUser: any = null;
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private empenoService: EmpenoService,
    private prendaService: PrendaService,
    private clienteService: ClienteService,
     @Inject(PLATFORM_ID) private platformId: Object
  ) {

              if (isPlatformBrowser(this.platformId)) {
      const userData = localStorage.getItem('currentUser');
      if (userData) {
        this.currentUser = JSON.parse(userData);
      }
    }
  }

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get("id")
    if (id) {
      this.loadEmpenoDetails(+id)
    } else {
      this.error = "ID de empeño no válido"
      this.loading = false
    }
  }

  loadEmpenoDetails(id: number): void {
    this.loading = true
    this.error = null

    this.empenoService.getEmpenoById(id).subscribe({
      next: (empeno) => {
        this.empeno = empeno
        this.loadRelatedData()
      },
      error: (err) => {
        console.error("Error al cargar empeño:", err)
        this.error = err.message || "Error al cargar el empeño"
        this.loading = false
      },
    })
  }

  loadRelatedData(): void {
    if (!this.empeno) return

    // Cargar prenda
    this.prendaService.getPrendaById(this.empeno.id).subscribe({
      next: (prenda) => {
        this.prenda = prenda
        this.checkLoadingComplete()
      },
      error: (err) => {
        console.error("Error al cargar prenda:", err)
        this.checkLoadingComplete()
      },
    })

    // Cargar cliente
    this.clienteService.getClienteById(this.empeno.cliente_id).subscribe({
      next: (cliente) => {
        this.cliente = cliente
        this.checkLoadingComplete()
      },
      error: (err) => {
        console.error("Error al cargar cliente:", err)
        this.checkLoadingComplete()
      },
    })
  }

  checkLoadingComplete(): void {
    // Verificar si ambas cargas han terminado (exitosa o con error)
    if (this.prenda !== null || this.cliente !== null) {
      this.loading = false
    }
  }

  deleteEmpeno(): void {
    if (!this.empeno) return

    const confirmMessage = `¿Estás seguro de que deseas eliminar el empeño #${this.empeno.id}?`
    if (confirm(confirmMessage)) {
      this.empenoService.deleteEmpeno(this.empeno.id).subscribe({
        next: () => {
          alert("Empeño eliminado correctamente")
          this.router.navigate(["/empenos"])
        },
        error: (err) => {
          console.error("Error al eliminar empeño:", err)
          alert("Error al eliminar el empeño: " + err.message)
        },
      })
    }
  }

  getEstadoClass(estado: string): string {
    switch (estado) {
      case "activo":
        return "estado-activo"
      case "pagado":
        return "estado-pagado"
      case "vencido":
        return "estado-vencido"
      case "perdido":
        return "estado-perdido"
      default:
        return ""
    }
  }

  getEstadoLabel(estado: string): string {
    switch (estado) {
      case "activo":
        return "Activo"
      case "pagado":
        return "Pagado"
      case "vencido":
        return "Vencido"
      case "perdido":
        return "Perdido"
      default:
        return estado
    }
  }

  isVencido(): boolean {
    if (!this.empeno) return false
    return new Date(this.empeno.fecha_vencimiento) < new Date()
  }

getDaysUntilExpiry(fecha: string | Date): number {
  const hoy = new Date();
  const fechaVencimiento = new Date(fecha);
  const diferencia = fechaVencimiento.getTime() - hoy.getTime();
  return Math.floor(diferencia / (1000 * 60 * 60 * 24));
}


  calculateTotalAmount(): number {
    if (!this.empeno) return 0
    return this.empeno.monto_prestado + (this.empeno.monto_prestado * this.empeno.interes_mensual) / 100
  }

  formatCurrency(amount: number): string {
    return new Intl.NumberFormat("es-CO", {
      style: "currency",
      currency: "COP",
    }).format(amount)
  }

  formatDate(date: Date): string {
    return new Date(date).toLocaleDateString("es-CO", {
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  goBack(): void {
    this.router.navigate(["/empenos"])
  }

  goToEdit(): void {
    if (this.empeno) {
      this.router.navigate(["/empenos", this.empeno.id, "editar"])
    }
  }

  goToCliente(): void {
    if (this.empeno) {
      this.router.navigate(["/clientes", this.empeno.cliente_id])
    }
  }

  public abs(value: number): number {
  return Math.abs(value)
}




}

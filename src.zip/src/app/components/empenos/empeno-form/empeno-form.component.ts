import { Component,  OnInit } from "@angular/core"
import { CommonModule } from "@angular/common"
import { ReactiveFormsModule,  FormBuilder,  FormGroup, Validators } from "@angular/forms"
import {  ActivatedRoute,  Router, RouterModule } from "@angular/router"
import  { EmpenoService } from "../../../services/empeno.service"
import  { PrendaService } from "../../../services/prenda.service"
import  { ClienteService } from "../../../services/cliente.service"
import  { Cliente } from "../../../models/cliente.model"
import  { Prenda } from "../../../models/prenda.model"
import  { CreateEmpenoRequest, UpdateEmpenoRequest } from "../../../models/empeno.model"
import { isPlatformBrowser } from '@angular/common';
import {  Inject, PLATFORM_ID } from '@angular/core';

@Component({
  selector: "app-empeno-form",
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule],
  templateUrl: "./empeno-form.component.html",
  styleUrls: ["./empeno-form.component.css"],
})
export class EmpenoFormComponent implements OnInit {
  empenoForm: FormGroup
  isEditMode = false
  empenoId: number | null = null
  clienteId: number | null = null

  clientes: Cliente[] = []
  prendasDisponibles: Prenda[] = []
  prendasSeleccionadas: Prenda[] = []
  currentUser: any = null;

  loading = false
  error: string | null = null

  estados = [
    { value: "activo", label: "Activo" },
    { value: "pagado", label: "Pagado" },
    { value: "vencido", label: "Vencido" },
    { value: "perdido", label: "Perdido" },
  ]

  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private empenoService: EmpenoService,
    private prendaService: PrendaService,
    private clienteService: ClienteService,
     @Inject(PLATFORM_ID) private platformId: Object
  ) {
    this.empenoForm = this.createForm()
                  if (isPlatformBrowser(this.platformId)) {
      const userData = localStorage.getItem('currentUser');
      if (userData) {
        this.currentUser = JSON.parse(userData);
      }
    }
  }

  ngOnInit(): void {
    this.checkRouteParams()
    this.loadClientes()
  }

  createForm(): FormGroup {
    return this.fb.group({
      clienteId: ["", [Validators.required]],
      prendaId: ["", [Validators.required]],
      monto_prestado: ["", [Validators.required, Validators.min(1)]],
      interes: ["", [Validators.required, Validators.min(0), Validators.max(100)]],
      fecha_vencimiento: ["", [Validators.required]],
      estado: ["activo", [Validators.required]],
      userId: [1], // Por ahora hardcodeado, debería venir del usuario logueado
    })
  }

  checkRouteParams(): void {
    const id = this.route.snapshot.paramMap.get("id")
    const clienteIdParam = this.route.snapshot.paramMap.get("clienteId")

    if (id && id !== "nuevo") {
      this.isEditMode = true
      this.empenoId = +id
      this.loadEmpenoForEdit()
    }

    if (clienteIdParam) {
      this.clienteId = +clienteIdParam
      this.empenoForm.patchValue({ clienteId: this.clienteId })
      this.onClienteChange()
    }
  }

  loadClientes(): void {
    this.clienteService.getClientes().subscribe({
      next: (clientes) => {
        this.clientes = clientes
      },
      error: (err) => {
        console.error("Error al cargar clientes:", err)
      },
    })
  }

  loadEmpenoForEdit(): void {
    if (!this.empenoId) return

    this.loading = true
    this.empenoService.getEmpenoById(this.empenoId).subscribe({
      next: (empeno) => {
        this.empenoForm.patchValue({
          clienteId: empeno.cliente_id,
          prendaId: empeno.prenda_id,
          monto_prestado: empeno.monto_prestado,
          interes: empeno.interes_mensual,
          fecha_vencimiento: this.formatDateForInput(empeno.fecha_vencimiento),
          estado: empeno.estado,
          userId: empeno.user_id,
        })
        this.onClienteChange()
        this.loading = false
      },
      error: (err) => {
        console.error("Error al cargar empeño:", err)
        this.error = err.message || "Error al cargar el empeño"
        this.loading = false
      },
    })
  }

  onClienteChange(): void {
    const clienteId = this.empenoForm.get("clienteId")?.value
    const empenoId = this.empenoForm.get("empenoId")?.value
    if (clienteId) {
      this.loadPrendasDisponibles(empenoId)
    } else {
      this.prendasDisponibles = []
      this.empenoForm.patchValue({ prendaId: "" })
    }
  }

  loadPrendasDisponibles(clienteId: number): void {
    this.prendaService.getPrendasByCliente(clienteId).subscribe({
      next: (prendas) => {
this.prendasDisponibles = Array.isArray(prendas)
  ? prendas.filter(
      (prenda) =>
        prenda.estado === "disponible" ||
        (this.isEditMode && prenda.estado === "empenada"),
    )
  : []

      },
      error: (err) => {
        console.error("Error al cargar prendas:", err)
        this.prendasDisponibles = []
      },
    })
  }

  onPrendaChange(): void {
    const prendaId = this.empenoForm.get("prendaId")?.value
    if (prendaId) {
      const prenda = this.prendasDisponibles.find((p) => p.id === +prendaId)
      if (prenda) {
        const montoSugerido = Math.floor(prenda.valor_estimado * 0.7)
        this.empenoForm.patchValue({ monto_prestado: montoSugerido })
      }
    }
  }

  calculateTotalAmount(): number {
    const monto = this.empenoForm.get("monto_prestado")?.value || 0
    const interes = this.empenoForm.get("interes")?.value || 0
    return monto + (monto * interes) / 100
  }

  getSelectedPrenda(): Prenda | null {
    const prendaId = this.empenoForm.get("prendaId")?.value
    return this.prendasDisponibles.find((p) => p.id === +prendaId) || null
  }

  onSubmit(): void {
    if (this.empenoForm.valid) {
      this.loading = true
      this.error = null

      const formData = this.empenoForm.value

      if (this.isEditMode && this.empenoId) {
        this.updateEmpeno(formData)
      } else {
        this.createEmpeno(formData)
      }
    } else {
      this.markFormGroupTouched()
    }
  }

  createEmpeno(data: CreateEmpenoRequest): void {
    this.empenoService.createEmpeno(data).subscribe({
      next: (empeno) => {
        alert("Empeño creado exitosamente")
        this.router.navigate(["/empenos", empeno.id])
      },
      error: (err) => {
        console.error("Error al crear empeño:", err)
        this.error = err.message || "Error al crear el empeño"
        this.loading = false
      },
    })
  }

  updateEmpeno(data: UpdateEmpenoRequest): void {
    if (!this.empenoId) return

    this.empenoService.updateEmpeno(this.empenoId, data).subscribe({
      next: (empeno) => {
        alert("Empeño actualizado exitosamente")
        this.router.navigate(["/empenos", empeno.id])
      },
      error: (err) => {
        console.error("Error al actualizar empeño:", err)
        this.error = err.message || "Error al actualizar el empeño"
        this.loading = false
      },
    })
  }

  markFormGroupTouched(): void {
    Object.keys(this.empenoForm.controls).forEach((key) => {
      const control = this.empenoForm.get(key)
      control?.markAsTouched()
    })
  }

  isFieldInvalid(fieldName: string): boolean {
    const field = this.empenoForm.get(fieldName)
    return !!(field && field.invalid && (field.dirty || field.touched))
  }

  getFieldError(fieldName: string): string {
    const field = this.empenoForm.get(fieldName)
    if (field?.errors) {
      if (field.errors["required"]) return `${fieldName} es requerido`
      if (field.errors["min"]) return `${fieldName} debe ser mayor a ${field.errors["min"].min}`
      if (field.errors["max"]) return `${fieldName} debe ser menor a ${field.errors["max"].max}`
    }
    return ""
  }

  formatDateForInput(date: Date): string {
    const d = new Date(date)
    return d.toISOString().split("T")[0]
  }

  formatCurrency(amount: number): string {
    return new Intl.NumberFormat("es-CO", {
      style: "currency",
      currency: "COP",
    }).format(amount)
  }

  goBack(): void {
    this.router.navigate(["/empenos"])
  }
}
